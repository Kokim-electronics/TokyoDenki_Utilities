var submit = document.querySelectorAll("button[type=submit]");
submit[0].id = "login";
document.getElementById("login").click();