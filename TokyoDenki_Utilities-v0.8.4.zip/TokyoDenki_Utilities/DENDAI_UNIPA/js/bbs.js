﻿var midoku = document.getElementsByClassName('ui-state-default ui-corner-top')[5];
if (midoku != undefined) {
    midoku.click();
}
