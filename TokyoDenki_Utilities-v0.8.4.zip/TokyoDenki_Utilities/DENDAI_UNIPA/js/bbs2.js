﻿var midoku = document.getElementsByClassName('ui-state-default ui-corner-top')[5];
if (midoku != undefined) {
    setTimeout(function () { document.getElementsByClassName('ui-state-default ui-corner-top')[5].click(); }, 500);
}
