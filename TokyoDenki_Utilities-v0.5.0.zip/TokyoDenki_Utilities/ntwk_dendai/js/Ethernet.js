chrome.storage.local.get(function (item) {
    if (document.getElementById("user") != undefined) {
        document.getElementById("user").value = item.uido_id.substr(0, item.uido_id.indexOf('@')).toLowerCase();
        document.getElementById("passwd").value = item.uido_pass;
        if (document.querySelectorAll("div[id=dError]")[0].childNodes[1].innerHTML != 'Invalid username or password'){
            document.getElementById("login_form").submit();
        }
        else {
            alert("【拡張機能のエラー】\nログインに失敗しました。\n拡張機能のオプションを確認した後，手動でログインしてください。");
    }
});